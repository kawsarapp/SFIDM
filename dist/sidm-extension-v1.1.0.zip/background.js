const SIDM_API = "http://127.0.0.1:45678";

// Helper: Extract cookies for target URL or domain (including HttpOnly session cookies)
async function getCookiesForUrl(urlStr) {
  if (!urlStr || urlStr.startsWith("blob:") || urlStr.startsWith("data:")) return null;
  try {
    const urlObj = new URL(urlStr);
    let cookies = await chrome.cookies.getAll({ url: urlStr });
    if (!cookies || cookies.length === 0) {
      cookies = await chrome.cookies.getAll({ domain: urlObj.hostname });
    }
    if (!cookies || cookies.length === 0) return null;
    return cookies.map((c) => `${c.name}=${c.value}`).join("; ");
  } catch (err) {
    console.warn("SIDM: Failed to retrieve cookies for", urlStr, err);
    return null;
  }
}

// Register context menus on install
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "sidm-download-link",
    title: "⚡ Download link with SIDM",
    contexts: ["link", "video", "audio", "image"]
  });

  chrome.contextMenus.create({
    id: "sidm-download-page-video",
    title: "🎬 Download video on page with SIDM",
    contexts: ["page"]
  });
});

// Handle context menu clicks
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  const targetUrl = info.linkUrl || info.srcUrl || info.pageUrl;
  if (!targetUrl) return;

  const cookies = await getCookiesForUrl(targetUrl);

  try {
    const res = await fetch(`${SIDM_API}/api/downloads`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        url: targetUrl,
        connections: 16,
        cookies: cookies || undefined
      })
    });
    const data = await res.json();
    if (data.success) {
      notifyTab(tab.id, "success", `SIDM: Download started!`);
    } else {
      notifyTab(tab.id, "error", `SIDM: ${data.error || "Failed"}`);
    }
  } catch (err) {
    notifyTab(tab.id, "error", "SIDM Core is not running. Please start SIDM!");
  }
});

// Listen to messages from content scripts
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "SEND_TO_SIDM") {
    (async () => {
      let payload = request.payload || {};
      if (!payload.cookies) {
        const targetUrl = payload.url && payload.url.startsWith("http") ? payload.url : sender.tab?.url;
        if (targetUrl) {
          const cookies = await getCookiesForUrl(targetUrl);
          if (cookies) {
            payload.cookies = cookies;
          }
        }
      }

      try {
        const res = await fetch(`${SIDM_API}/api/downloads`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload)
        });
        const data = await res.json().catch(() => ({}));
        if (!res.ok) {
          sendResponse({ success: false, error: data.error || `Server HTTP ${res.status}` });
        } else {
          sendResponse({ success: true, data });
        }
      } catch (err) {
        console.warn("SIDM backend unreachable:", err.message);
        sendResponse({
          success: false,
          error: "SIDM Engine is offline! Make sure SIDM is running."
        });
      }
    })();
    return true; // Keep message channel open for async response
  }

  if (request.action === "GET_TASK_STATUS") {
    if (!request.taskId) {
      fetch(`${SIDM_API}/api/downloads`)
        .then((res) => res.json())
        .then((tasks) => {
          const task = tasks && tasks.length > 0 ? tasks[0] : null;
          sendResponse({ success: true, task });
        })
        .catch(() => sendResponse({ success: false }));
      return true;
    }

    fetch(`${SIDM_API}/api/downloads/${request.taskId}`)
      .then((res) => res.json())
      .then((data) => sendResponse({ success: true, task: data.task }))
      .catch((err) => sendResponse({ success: false, error: err.message }));
    return true;
  }

  if (request.action === "OPEN_TASK_FOLDER") {
    const url = request.taskId ? `${SIDM_API}/api/downloads/${request.taskId}/open-folder` : `${SIDM_API}/api/open-folder`;
    fetch(url, { method: "POST" })
      .then((res) => res.json())
      .then((data) => sendResponse(data))
      .catch((err) => sendResponse({ success: false, error: err.message }));
    return true;
  }

  if (request.action === "OPEN_TASK_FILE") {
    if (!request.taskId) return;
    fetch(`${SIDM_API}/api/downloads/${request.taskId}/open-file`, { method: "POST" })
      .then((res) => res.json())
      .then((data) => sendResponse(data))
      .catch((err) => sendResponse({ success: false, error: err.message }));
    return true;
  }

  if (request.action === "INSPECT_MEDIA") {
    (async () => {
      let cookies = request.cookies;
      if (!cookies && request.url) {
        cookies = await getCookiesForUrl(request.url);
      }
      fetch(`${SIDM_API}/api/inspect`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: request.url, cookies: cookies || undefined })
      })
        .then((res) => res.json())
        .then((data) => sendResponse({ success: true, data }))
        .catch((err) => sendResponse({ success: false, error: err.message }));
    })();
    return true;
  }

  if (request.action === "INSPECT_PLAYLIST") {
    (async () => {
      let cookies = request.cookies;
      if (!cookies && request.url) {
        cookies = await getCookiesForUrl(request.url);
      }
      fetch(`${SIDM_API}/api/playlist/inspect`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: request.url, cookies: cookies || undefined })
      })
        .then((res) => res.json())
        .then((data) => sendResponse(data))
        .catch((err) => sendResponse({ success: false, error: err.message }));
    })();
    return true;
  }

  if (request.action === "BATCH_DOWNLOAD") {
    fetch(`${SIDM_API}/api/downloads/batch`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(request.payload)
    })
      .then((res) => res.json())
      .then((data) => sendResponse(data))
      .catch((err) => sendResponse({ success: false, error: err.message }));
    return true;
  }
});

function notifyTab(tabId, type, message) {
  if (!tabId) return;
  chrome.tabs.sendMessage(tabId, {
    action: "SHOW_TOAST",
    type,
    message
  }).catch(() => {});
}
